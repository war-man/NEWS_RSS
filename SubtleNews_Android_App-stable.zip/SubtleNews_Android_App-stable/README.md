SubtleNews Android App
======================

[![Build Status](https://travis-ci.org/teamOSC/SubtleNews_Android_App.svg?branch=dev)](https://travis-ci.org/teamOSC/SubtleNews_Android_App)

###Play Store download link
[Free version] (https://play.google.com/store/apps/details?id=in.ac.dtu.subtlenews.free)
