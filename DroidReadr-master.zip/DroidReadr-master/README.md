# DroidReadr
RSS Reader for medium.com website. The main purpose of the application is to grab the feed of the most popular Android publications on the Medium website and display them in a easy to read manner for the user. The user can filter these posts. The main asset of the application is the Clustering Algorithm that's going to sort the similar news with regard to the frequency vector.
