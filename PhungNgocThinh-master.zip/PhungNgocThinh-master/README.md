# PhungNgocThinh
App Đọc báo online
# Download Read online news

Click here:  [Read online news apk](https://github.com/phungthinh1204/PhungNgocThinh/blob/master/app-debug.apk) 

# Read online news <img width="50px" heigh="50px" src="https://pbs.twimg.com/profile_images/766833986916093953/y3N_Wgqm_400x400.jpg">

# Trang chủ.
<p align="center"><img src="https://scontent.fhan2-2.fna.fbcdn.net/v/t1.15752-9/56567267_312002166158919_3703497389638680576_n.png?_nc_cat=111&_nc_oc=AQlnxx-RojCNfUAJgjxzc5TE4geu5ypw9xKzZkIkjoWDFevsdYZU2jFbgPmE9Yy_4-4&_nc_ht=scontent.fhan2-2.fna&oh=4e1574f20499aca128d075125b160e11&oe=5D3A8EB3" alt="" height="300"></p>

# Ứng dụng đọc báo
<p align="center"><img src="https://scontent.fhan2-4.fna.fbcdn.net/v/t1.15752-9/56590980_781117365618905_4963159169537409024_n.png?_nc_cat=104&_nc_oc=AQlmn2P0FXamWWUTkmEpnI-oXBQ5gosz4_y2YVZLVbvPJtErPqSgMhDMUm7CkQmk1mQ&_nc_ht=scontent.fhan2-4.fna&oh=886439fb3e10030fed3ec6ff08f93d3b&oe=5D356506" alt="" height="300"></p>
Ứng dụng có giao diện phẳng, nhất quán với thiết kế một cột ảnh - tiêu đề giúp thông tin được hiển thị trực quan và việc duyệt tin tức dễ dàng hơn.
Độc giả bấm vào Menu ở góc trái trên cùng ứng dụng, hoặc chỉ cần vuốt ngang màn hình để truy cập từng chuyên mục.

# Danh mục đọc báo
<p align="center"><img src="https://scontent.fhan2-2.fna.fbcdn.net/v/t1.15752-9/57240604_532627467266093_7053959471252373504_n.png?_nc_cat=106&_nc_oc=AQnQj0tpJUg1lHTjyZdSy5ashkJD48D-JiMqr4ZFO1znlCMuIlDp-RcP-1T0iVWHTzk&_nc_ht=scontent.fhan2-2.fna&oh=98380ac03b555f3a7de5708573fb464e&oe=5D3BEC02" alt="" height="300"></p>

# Lưu lại đọc offline
<p align="center"><img src="https://scontent.fhan2-1.fna.fbcdn.net/v/t1.15752-9/57216771_2049784665120210_7719983472932028416_n.png?_nc_cat=103&_nc_oc=AQnu6-Q4BQqbG0RghK4tXGVas7xaYd9ovG9X1MprkXtPTf0Vfdmm9rdHOdc_YnHeZkw&_nc_ht=scontent.fhan2-1.fna&oh=d7f9227042070d1113775a00f52e150e&oe=5D3EE49F" alt="" height="300"></p>
Bài đã lưu có thể được đọc ở chế độ offline (Không có mạng).
Xóa bài viết đã lưu nếu đã đọc xong.
