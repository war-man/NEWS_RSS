package com.example.admin.docbaoonline.Activity;

/**
 * Created by Thinh Phung on 3/14/2018.
 */

public class StaticDataVNExpress {
    public static String urlTrangChu = "https://vnexpress.net/rss/tin-moi-nhat.rss";
    public static String urlCongDong = "https://vnexpress.net/rss/cong-dong.rss";
    public static String urlCuoi = "https://vnexpress.net/rss/cuoi.rss";
    public static String urlDuLich = "https://vnexpress.net/rss/du-lich.rss";
    public static String urlGiaDinh = "https://vnexpress.net/rss/gia-dinh.rss";
    public static String urlGiaiTri = "https://vnexpress.net/rss/giai-tri.rss";
    public static String urlGiaoDuc = "https://vnexpress.net/rss/giao-duc.rss";
    public static String urlKhoaHoc = "https://vnexpress.net/rss/khoa-hoc.rss";
    public static String urlKinhDoanh = "https://vnexpress.net/rss/kinh-doanh.rss";
    public static String urlPhapLuat = "https://vnexpress.net/rss/phap-luat.rss";
    public static String urlTheGioi = "https://vnexpress.net/rss/the-gioi.rss";
    public static String urlThoiSu = "https://vnexpress.net/rss/thoi-su.rss";
    public static String urlSoHoa = "https://vnexpress.net/rss/so-hoa.rss";
    public static String urlStartUp = "https://vnexpress.net/rss/startup.rss";
    public static String urlSucKhoe = "https://vnexpress.net/rss/suc-khoe.rss";
    public static String urlTamSu = "https://vnexpress.net/rss/tam-su.rss";
    public static String urlTheThao = "https://vnexpress.net/rss/the-thao.rss";
    public static String urlXe = "https://vnexpress.net/rss/oto-xe-may.rss";
}
