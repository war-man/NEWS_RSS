package com.example.rssfeed.base;

import android.content.Context;

import com.example.rssfeed.repositories.RSSFeedsRepositoryImp;

public interface DependencyInjector {
    RSSFeedsRepository keywordsRepository(Context context, RSSFeedsRepositoryImp.Listener listener);
}
