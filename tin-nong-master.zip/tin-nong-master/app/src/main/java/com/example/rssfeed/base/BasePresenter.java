package com.example.rssfeed.base;

interface BasePresenter {
    void onDestroy();
}
