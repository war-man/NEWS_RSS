package com.example.rssfeed.activities;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.widget.ProgressBar;
import android.widget.TextView;

import androidx.annotation.NonNull;

import com.example.rssfeed.R;
import com.example.rssfeed.base.ContentContract;
import com.example.rssfeed.injectors.DependencyInjectorImpl;
import com.example.rssfeed.presenters.ContentPresenter;

public class ContentActivity extends BaseActivity implements ContentContract.View {
    private static final String HTML_DATA = "HTML_DATA";
    protected ContentContract.Presenter presenter;
    protected WebView myWebView;
    protected ProgressBar progress;
    protected TextView error_message;
    protected String htmlData;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_content);
        myWebView = findViewById(R.id.webview);
        WebSettings webSettings = myWebView.getSettings();
        if (isDarkMode) {
            myWebView.setBackgroundColor(Color.BLACK);
        }
        webSettings.setJavaScriptEnabled(true);

        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        progress = findViewById(R.id.progress_bar);
        error_message = findViewById(R.id.error_message);
        Intent intent = getIntent();
        String url = intent.getStringExtra("url");

        setPresenter(new ContentPresenter(this, this, new DependencyInjectorImpl()));
        if (savedInstanceState != null) {
            this.htmlData = (String) savedInstanceState.getSerializable(HTML_DATA);
        }
        if (this.htmlData != null && !this.htmlData.isEmpty()) {
            this.showHtmlData(this.htmlData);
        } else {
            this.presenter.showArtileOnWebview(url);
        }
    }

    @Override
    public void onSaveInstanceState(Bundle savedInstanceState) {
        // Save currently selected layout manager.
        savedInstanceState.putSerializable(HTML_DATA, this.htmlData);
        super.onSaveInstanceState(savedInstanceState);
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                this.onBackPressed();
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }

    @Override
    protected void onDestroy() {
        this.presenter.onDestroy();
        super.onDestroy();
    }

    @Override
    public void showLoading() {
        progress.setVisibility(View.VISIBLE);
    }

    @Override
    public void hideLoading() {
        progress.setVisibility(View.INVISIBLE);
    }

    @Override
    public void showHtmlData(String htmlData) {
        this.htmlData = htmlData;
        this.myWebView.setVisibility(View.VISIBLE);
        this.error_message.setVisibility(View.INVISIBLE);
        if (isDarkMode) {
            this.myWebView.loadDataWithBaseURL("file:///android_asset/.", htmlData, "text/html", "UTF-8", null);
        } else {
            this.myWebView.loadDataWithBaseURL(null, htmlData, "text/html", "UTF-8", null);
        }
    }

    @Override
    public void showErrorMessage(String error) {
        this.myWebView.setVisibility(View.INVISIBLE);
        this.error_message.setVisibility(View.VISIBLE);
        this.error_message.setText(error);
    }

    @Override
    public void setPresenter(ContentContract.Presenter presenter) {
        this.presenter = presenter;
    }
}
