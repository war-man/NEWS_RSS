package com.example.rssfeed.fragments;

import android.app.ProgressDialog;
import android.os.Bundle;
import android.os.Handler;
import android.os.Parcelable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ProgressBar;
import android.widget.TextView;

import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;

import com.example.rssfeed.base.MainContract;
import com.example.rssfeed.base.MainContract.Presenter;
import com.example.rssfeed.presenters.MainPresenter;
import com.example.rssfeed.R;
import com.example.rssfeed.RecyclerViewAdapter;
import com.example.rssfeed.injectors.DependencyInjectorImpl;
import com.example.rssfeed.models.Article;

import java.util.ArrayList;
import java.util.List;

public class RecyclerViewFragment extends Fragment implements MainContract.View {

    private static final String KEY_DATASET = "DATASET";
    protected RecyclerView mRecyclerView;
    protected RecyclerViewAdapter mAdapter;
    protected RecyclerView.LayoutManager mLayoutManager;
    protected List<Article> mDataset = new ArrayList<>();

    protected TextView errorMessagetxt;
    protected ProgressBar progress;
    protected SwipeRefreshLayout mSwipeRefreshLayout;
    protected Presenter presenter;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if(savedInstanceState != null){
            mDataset = savedInstanceState.getParcelableArrayList(this.KEY_DATASET);
        }
        setPresenter(new MainPresenter(this.getContext(), this, new DependencyInjectorImpl()));
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View rootView = inflater.inflate(R.layout.recyclerview_fragment, container, false);

        mRecyclerView = rootView.findViewById(R.id.rss_feeds_recyclerView);
        mLayoutManager = new LinearLayoutManager(getActivity());
        mAdapter = new RecyclerViewAdapter(mDataset);
        mRecyclerView.setAdapter(mAdapter);
        mRecyclerView.setLayoutManager(mLayoutManager);

        errorMessagetxt = rootView.findViewById(R.id.error_message);
        mSwipeRefreshLayout = rootView.findViewById(R.id.swiperefresh_items);
        mSwipeRefreshLayout.setOnRefreshListener(new SwipeRefreshLayout.OnRefreshListener() {
            @Override
            public void onRefresh() {
                presenter.fetchRSSFeeds();

                final Handler handler = new Handler();
                handler.postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        if (mSwipeRefreshLayout.isRefreshing()) {
                            mSwipeRefreshLayout.setRefreshing(false);
                        }
                    }
                }, 1000);
            }
        });
        progress = rootView.findViewById(R.id.progress_bar);
        if (this.mDataset.size() == 0) {
            this.showLoading();
            presenter.fetchRSSFeeds();
        }

        return rootView;
    }

    @Override
    public void onSaveInstanceState(Bundle savedInstanceState) {
        // Save currently selected layout manager.
        savedInstanceState.putParcelableArrayList(KEY_DATASET, new ArrayList<Parcelable>(this.mDataset));
        super.onSaveInstanceState(savedInstanceState);
    }

    @Override
    public void onDestroy() {
        presenter.onDestroy();
        super.onDestroy();
    }

    @Override
    public void setPresenter(Presenter presenter) {
        this.presenter = presenter;
    }

    @Override
    public void populateFeeds(List<Article> feeds) {
        this.mRecyclerView.setVisibility(View.VISIBLE);
        this.errorMessagetxt.setVisibility(View.INVISIBLE);
        this.mDataset = feeds;
        this.mAdapter.setFeeds(feeds);
        this.mAdapter.notifyDataSetChanged();
    }

    @Override
    public void showErrorMessage(String error) {
        this.mRecyclerView.setVisibility(View.INVISIBLE);
        this.errorMessagetxt.setVisibility(View.VISIBLE);
        this.errorMessagetxt.setText(error);
    }

    public void showLoading() {
        this.progress.setVisibility(View.VISIBLE);
    }

    public void hideLoading() {
        this.progress.setVisibility(View.INVISIBLE);
    }
}