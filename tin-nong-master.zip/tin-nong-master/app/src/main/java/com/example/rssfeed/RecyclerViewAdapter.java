package com.example.rssfeed;

import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.RecyclerView;

import com.example.rssfeed.activities.ContentActivity;
import com.example.rssfeed.activities.MainActivity;
import com.example.rssfeed.models.Article;
import com.squareup.picasso.Picasso;

import java.util.List;


public class RecyclerViewAdapter extends RecyclerView.Adapter<RecyclerViewAdapter.ItemHolder> {

    private List<Article> feeds;
    public RecyclerViewAdapter(List<Article> feeds) {
        this.setFeeds(feeds);
    }

    @NonNull
    @Override
    public ItemHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.feed_card_item, parent, false);
        ItemHolder itemHolder = new ItemHolder(view);
        return itemHolder;
    }

    @Override
    public void onBindViewHolder(@NonNull final ItemHolder holder, final int position) {
        holder.titleTxt.setText(getFeeds().get(position).getTitle());
        holder.descriptionTxt.setText(getFeeds().get(position).getDescription());
        String thumbnail = getFeeds().get(position).getThumbnail();
        if (thumbnail !=null && !thumbnail.isEmpty()) {
            Picasso.get().load(thumbnail).fit().into(holder.thumbnail);
        }
        holder.cardView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(v.getContext(), ContentActivity.class);
                intent.putExtra("url", getFeeds().get(position).getLink());
                v.getContext().startActivity(intent);
            }
        });
    }

    @Override
    public int getItemCount() {
        return getFeeds().size();
    }

    public List<Article> getFeeds() {
        return feeds;
    }

    public void setFeeds(List<Article> feeds) {
        this.feeds = feeds;
    }

    public class ItemHolder extends RecyclerView.ViewHolder {

        TextView titleTxt;
        TextView descriptionTxt;
        ImageView thumbnail;
        CardView cardView;
        public ItemHolder(@NonNull View itemView) {
            super(itemView);
            cardView = itemView.findViewById(R.id.card_view);
            titleTxt = itemView.findViewById(R.id.title);
            descriptionTxt = itemView.findViewById(R.id.description);
            thumbnail = itemView.findViewById(R.id.thumbnail);
        }
    }
}
