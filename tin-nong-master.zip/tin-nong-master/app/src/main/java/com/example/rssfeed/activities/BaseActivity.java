package com.example.rssfeed.activities;

import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.CompoundButton;
import android.widget.Switch;

import androidx.appcompat.app.AppCompatActivity;

import com.example.rssfeed.R;


public class BaseActivity extends AppCompatActivity {

    public static final String TAG = "BaseActivity";
    protected static final String IS_USING_DARK_THEME_KEY = "IS_USING_DARK_THEME";
    protected Switch darkmodeSwitch;
    protected static boolean isDarkMode;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        if (savedInstanceState != null) {
            isDarkMode = savedInstanceState.getBoolean(IS_USING_DARK_THEME_KEY, false);
        }
        if (isDarkMode) {
            setTheme(R.style.DarkTheme);
        }
        super.onCreate(savedInstanceState);
    }

    @Override
    protected void onStart() {
        super.onStart();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu, menu);
        MenuItem darkmodeItem = menu.findItem(R.id.darkmode_item);
        darkmodeItem.setActionView(R.layout.switch_layout);
        darkmodeSwitch = darkmodeItem.getActionView().findViewById(R.id.darkmode_switch);
        darkmodeSwitch.setChecked(isDarkMode);
        darkmodeSwitch.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if (isChecked) {
                    getApplication().setTheme(R.style.DarkTheme);
                    recreate();
                } else {
                    getApplication().setTheme(R.style.LightTheme);
                    recreate();
                }
            }
        });
        return true;
    }

    @Override
    public boolean onPrepareOptionsMenu(Menu menu) {
        return super.onPrepareOptionsMenu(menu);
    }

    @Override
    public void onSaveInstanceState(Bundle savedInstanceState) {
        savedInstanceState.putSerializable(IS_USING_DARK_THEME_KEY, darkmodeSwitch.isChecked());
        super.onSaveInstanceState(savedInstanceState);
    }
}
