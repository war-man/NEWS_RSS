package com.example.rssfeed.models;

import android.os.Parcel;
import android.os.Parcelable;

public class Article implements Parcelable {
    private String title;
    private String description;
    private String thumbnail;
    private String link;
    private String publicDate;
    private int comments;

    Article(String title, String description, String thumbnail, String link, String publicDate, int comments) {
        this.title = title;
        this.description = description;
        this.thumbnail=thumbnail;
        this.link = link;
        this.publicDate = publicDate;
        this.comments = comments;
    }

    protected Article(Parcel in) {
        title = in.readString();
        description = in.readString();
        link = in.readString();
        publicDate = in.readString();
        comments = in.readInt();
        thumbnail = in.readString();
    }

    public static final Creator<Article> CREATOR = new Creator<Article>() {
        @Override
        public Article createFromParcel(Parcel in) {
            return new Article(in);
        }

        @Override
        public Article[] newArray(int size) {
            return new Article[size];
        }
    };

    public Article() {

    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getLink() {
        return link;
    }

    public void setLink(String link) {
        this.link = link;
    }

    public String getPublicDate() {
        return publicDate;
    }

    public void setPublicDate(String publicDate) {
        this.publicDate = publicDate;
    }

    public int getComments() {
        return comments;
    }

    public void setComments(int comments) {
        this.comments = comments;
    }

    public String getThumbnail() {
        return thumbnail;
    }

    public void setThumbnail(String thumbnail) {
        this.thumbnail = thumbnail;
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(title);
        dest.writeString(description);
        dest.writeString(link);
        dest.writeString(publicDate);
        dest.writeInt(comments);
        dest.writeString(thumbnail);
    }
}
