package com.example.rssfeed.base;

public interface RSSFeedsRepository {
    void fetchRSSFeeds(String url);
    void downloadArticle(String url);
}
