package com.example.rssfeed.base;

interface BaseView<T> {
    void setPresenter(T t);
}
