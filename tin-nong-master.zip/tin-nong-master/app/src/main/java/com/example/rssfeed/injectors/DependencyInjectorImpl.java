package com.example.rssfeed.injectors;

import android.content.Context;

import com.example.rssfeed.base.DependencyInjector;
import com.example.rssfeed.base.RSSFeedsRepository;
import com.example.rssfeed.repositories.RSSFeedsRepositoryImp;
import com.example.rssfeed.repositories.RSSFeedsRepositoryImp.Listener;

public class DependencyInjectorImpl implements DependencyInjector {

    @Override
    public RSSFeedsRepository keywordsRepository(Context context, Listener listener) {
        return new RSSFeedsRepositoryImp(context, listener);
    }
}

