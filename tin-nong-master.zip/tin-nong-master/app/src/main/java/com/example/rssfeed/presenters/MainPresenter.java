package com.example.rssfeed.presenters;

import android.content.Context;

import com.example.rssfeed.Constant;
import com.example.rssfeed.NetworkUtil;
import com.example.rssfeed.base.MainContract;
import com.example.rssfeed.base.DependencyInjector;
import com.example.rssfeed.models.Article;
import com.example.rssfeed.repositories.RSSFeedsRepositoryImp;

import java.util.List;

public class MainPresenter implements MainContract.Presenter, RSSFeedsRepositoryImp.Listener {

    private com.example.rssfeed.base.RSSFeedsRepository RSSFeedsRepository;
    private MainContract.View view;
    private Context context;
    public MainPresenter(Context context, MainContract.View view, DependencyInjector dependencyInjector) {
        this.context = context;
        this.view = view;
        this.RSSFeedsRepository = dependencyInjector.keywordsRepository(context, this);
    }

    @Override
    public void fetchRSSFeeds() {
        if(!NetworkUtil.isNetworkConnected(this.context)){
            this.view.showErrorMessage(Constant.NO_INTERNET);
            return;
        }
        RSSFeedsRepository.fetchRSSFeeds(Constant.RSS_FEED);
    }

    @Override
    public void onDestroy() {
        this.view = null;
    }

    @Override
    public void onComplete(List<Article> feeds) {
        this.view.hideLoading();
        if (view != null) {
            view.populateFeeds(feeds);
        }
    }

    @Override
    public void onDownloadArticleSuccess(String htmlData) {
        // do nothing
    }

    @Override
    public void onError(String error) {
        this.view.showErrorMessage(error);
        this.view.hideLoading();
    }
}