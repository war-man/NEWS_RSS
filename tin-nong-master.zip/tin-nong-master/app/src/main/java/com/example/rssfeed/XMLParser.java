package com.example.rssfeed;

import android.util.Xml;

import com.example.rssfeed.models.Article;

import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserException;

import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class XMLParser {
    // We don't use namespaces
    private static final String ns = null;

    public List parse(InputStream in) throws XmlPullParserException, IOException {
        try {
            XmlPullParser parser = Xml.newPullParser();
            parser.setFeature(XmlPullParser.FEATURE_PROCESS_NAMESPACES, false);
            parser.setInput(in, null);
            parser.nextTag();
            while (parser.getEventType() == XmlPullParser.START_TAG && !parser.getName().equalsIgnoreCase("channel")) {
                parser.nextTag();
            }
            return readChannel(parser);
        } finally {
            in.close();
        }
    }

    private List readChannel(XmlPullParser parser) throws XmlPullParserException, IOException {
        List articles = new ArrayList();
        parser.require(XmlPullParser.START_TAG, ns, "channel");
        while (parser.next() != XmlPullParser.END_TAG) {
            if (parser.getEventType() != XmlPullParser.START_TAG) {
                continue;
            }
            String name = parser.getName();
            if (name.equals("item")) {
                articles.add(readItem(parser));
            } else {
                skip(parser);
            }
        }
        return articles;
    }

    private Article readItem(XmlPullParser parser) throws XmlPullParserException, IOException {
        parser.require(XmlPullParser.START_TAG, ns, "item");
        Article article = new Article();

        while (parser.next() != XmlPullParser.END_TAG) {
            if (parser.getEventType() != XmlPullParser.START_TAG) {
                continue;
            }
            String tagname = parser.getName();
            if (tagname.equals("title")) {
                article.setTitle(readTitle(parser));
            } else if (tagname.equals("description")) {
                readDescription(article, parser);
            } else {
                skip(parser);
            }
        }
        return article;
    }

    private String readTitle(XmlPullParser parser) throws IOException, XmlPullParserException {
        parser.require(XmlPullParser.START_TAG, ns, "title");
        String title = readText(parser);
        parser.require(XmlPullParser.END_TAG, ns, "title");
        return title;
    }

    private String readDescription(Article article, XmlPullParser parser) throws IOException, XmlPullParserException {
        parser.require(XmlPullParser.START_TAG, ns, "description");
        String s = "";
        String link = "";
        String thumbnailSource = "";
        String description = "";
        if (parser.next() == XmlPullParser.TEXT) {
            s = parser.getText();
            if (s == null) { //what would happen if it encounters in fact a cdsect
                int event = parser.nextToken();    //this is the main technical important line
                if (event == XmlPullParser.CDSECT) {
                    s = parser.getText();
                }
            }
            if (s != null) {
                Pattern hrefPattern = Pattern.compile("<a\\b.*?\\shref\\s*=\\s*(\"|')(.*?)(\\1)");
                Matcher hrefMatcher = hrefPattern.matcher(s);
                link = (hrefMatcher.find()) ? hrefMatcher.group(2) : "";

                Pattern thumbOriginalPattern = Pattern.compile("<img\\b.*\\sdata-original\\s*=\\s*(\"|')(.*?)(\\1)");
                Matcher thumbOriginalMatcher = thumbOriginalPattern.matcher(s);

                Pattern thumbSrcPattern = Pattern.compile("<img\\b.*?\\ssrc\\s*=\\s*(\"|')(.*?)(\\1)");
                Matcher thumbSrcMatcher = thumbSrcPattern.matcher(s);
                thumbnailSource = thumbOriginalMatcher.find() ? thumbOriginalMatcher.group(2):
                        (thumbSrcMatcher.find() ? thumbSrcMatcher.group(2): "");


                Pattern descriptionPattern = Pattern.compile("(<\\/br>|<br>)(.*)");
                Matcher descriptionMatcher = descriptionPattern.matcher(s);
                description = (descriptionMatcher.find()) ? descriptionMatcher.group(2) : "";

                article.setDescription(description);
                article.setLink(link);
                article.setThumbnail(thumbnailSource);

            }
            parser.nextTag();
        }
        parser.require(XmlPullParser.END_TAG, ns, "description");
        return link;
    }

    private String readText(XmlPullParser parser) throws IOException, XmlPullParserException {
        String result = "";
        if (parser.next() == XmlPullParser.TEXT) {
            result = parser.getText();
            parser.nextTag();
        }
        return result;
    }

    private void skip(XmlPullParser parser) throws XmlPullParserException, IOException {
        if (parser.getEventType() != XmlPullParser.START_TAG) {
            throw new IllegalStateException();
        }
        int depth = 1;
        while (depth != 0) {
            switch (parser.next()) {
                case XmlPullParser.END_TAG:
                    depth--;
                    break;
                case XmlPullParser.START_TAG:
                    depth++;
                    break;
            }
        }
    }

}
