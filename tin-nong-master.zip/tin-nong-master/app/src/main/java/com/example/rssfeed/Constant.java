package com.example.rssfeed;

public class Constant {
    public static String RSS_FEED = "https://vnexpress.net/rss/tin-moi-nhat.rss";
    public static String NO_INTERNET = "Please check your network before continue";
}
