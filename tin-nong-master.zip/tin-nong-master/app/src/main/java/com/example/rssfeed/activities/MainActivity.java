package com.example.rssfeed.activities;

import android.os.Bundle;
import android.util.Log;

import androidx.fragment.app.FragmentTransaction;

import com.example.rssfeed.R;
import com.example.rssfeed.fragments.RecyclerViewFragment;

public class MainActivity extends BaseActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        if (savedInstanceState == null) {
            FragmentTransaction transaction = getSupportFragmentManager().beginTransaction();
            RecyclerViewFragment fragment = new RecyclerViewFragment();
            transaction.replace(R.id.recyclerview_fragment, fragment);
            transaction.commit();
        }
    }

    @Override
    protected void onStart() {
        Log.d("lamvp", "Main activity started");
        if (this.darkmodeSwitch != null && this.darkmodeSwitch.isChecked() != this.isDarkMode) {
            this.darkmodeSwitch.setChecked(this.isDarkMode);
        }
        super.onStart();
    }

    @Override
    protected void onRestart() {
        Log.d("lamvp", "Main activity restarted");
        super.onRestart();
    }

    @Override
    protected void onResume() {
        Log.d("lamvp", "Main activity resumed");
        super.onResume();
    }

    @Override
    protected void onPause() {
        Log.d("lamvp", "Main activity paused");
        super.onPause();
    }

    @Override
    protected void onStop() {
        Log.d("lamvp", "Main activity stopped");
        super.onStop();
    }

    @Override
    protected void onDestroy() {
        Log.d("lamvp", "Main activity destroyed");
        super.onDestroy();
    }
}
