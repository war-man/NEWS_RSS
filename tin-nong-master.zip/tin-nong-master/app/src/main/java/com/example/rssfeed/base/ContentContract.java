package com.example.rssfeed.base;

import com.example.rssfeed.models.Article;

import java.util.List;

public interface ContentContract {
    interface Presenter extends BasePresenter {
        void showArtileOnWebview(String articleLink);
    }

    interface View extends BaseView<Presenter> {
        void showLoading();
        void hideLoading();
        void showHtmlData(String htmlData);
        void showErrorMessage(String error);
    }
}