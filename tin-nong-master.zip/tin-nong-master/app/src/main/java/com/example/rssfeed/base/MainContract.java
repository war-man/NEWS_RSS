package com.example.rssfeed.base;

import com.example.rssfeed.models.Article;

import java.util.List;

public interface MainContract {
    interface Presenter extends BasePresenter {
        void fetchRSSFeeds();
    }

    interface View extends BaseView<Presenter> {
        void showLoading();
        void hideLoading();
        void populateFeeds(List<Article> feeds);
        void showErrorMessage(String error);
    }
}