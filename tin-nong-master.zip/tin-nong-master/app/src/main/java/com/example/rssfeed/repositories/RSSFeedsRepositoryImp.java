package com.example.rssfeed.repositories;

import android.content.Context;
import android.os.AsyncTask;
import android.text.TextUtils;
import android.util.Log;

import com.android.volley.Network;
import com.android.volley.RequestQueue;
import com.android.volley.toolbox.Volley;
import com.example.rssfeed.NetworkUtil;
import com.example.rssfeed.XMLParser;
import com.example.rssfeed.base.RSSFeedsRepository;
import com.example.rssfeed.models.Article;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.xmlpull.v1.XmlPullParserException;

import java.io.IOException;
import java.io.InputStream;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.List;

public class RSSFeedsRepositoryImp implements RSSFeedsRepository {

    private RequestQueue requestQueue;
    private Listener listener;

    public RSSFeedsRepositoryImp(Context context, Listener listener) {
        requestQueue = Volley.newRequestQueue(context);
        this.listener = listener;
    }

    @Override
    public void fetchRSSFeeds(String url) {
//        requestQueue.add(createFetchRSSFeedsRequest(listener));
        new FetchFeedTask(url).execute((Void) null);
    }

    @Override
    public void downloadArticle(String url) {
        new DownloadArticleTask(url).execute((Void) null);
    }

//    private StringRequest createFetchRSSFeedsRequest(final Listener listener) {
//        StringRequest rssFeedsRequest = new StringRequest(RSS_FEED, new Response.Listener<String>() {
//            @Override
//            public void onResponse(String response) {
//                XMLParser parser = new XMLParser();
//                List<Article> articles;
//                try {
//                    articles = parser.parse(new ByteArrayInputStream(response.getBytes()));
//                    listener.onComplete(articles);
//                } catch (XmlPullParserException e) {
//                    e.printStackTrace();
//                } catch (IOException e) {
//                    e.printStackTrace();
//                }
//            }
//        }, new Response.ErrorListener() {
//            @Override
//            public void onErrorResponse(VolleyError error) {
//
//            }
//        });
//        return rssFeedsRequest;
//    }

    private class FetchFeedTask extends AsyncTask<Void, Void, List<Article>> {

        private String urlLink;
        private String errorMessage;

        FetchFeedTask(String link) {
            this.urlLink = link;
        }

        @Override
        protected void onPreExecute() {
        }

        @Override
        protected List<Article> doInBackground(Void... voids) {
            if (TextUtils.isEmpty(urlLink))
                return null;
            if (!urlLink.startsWith("http://") && !urlLink.startsWith("https://"))
                urlLink = "http://" + urlLink;
            try {
                List<Article> articles = null;
                int retry = 5;
                while ((articles == null || articles.size() == 0) && retry != 0) {
                    URL url = new URL(urlLink);
                    InputStream inputStream = url.openConnection().getInputStream();
                    XMLParser parser = new XMLParser();
                    articles = parser.parse(inputStream);
                    retry--;
                }
                return articles;
            } catch (XmlPullParserException e) {
                this.errorMessage = "It seems the app is using an unfamiliar rss news feed";
                e.printStackTrace();
            } catch (MalformedURLException e) {
                this.errorMessage = "Please check your rss news feed url before re try again";
                e.printStackTrace();
            } catch (IOException e) {
                this.errorMessage = "The device might be out of disk space";
                e.printStackTrace();
            }
            return null;
        }

        @Override
        protected void onPostExecute(List<Article> articles) {
            if (articles != null && articles.size() != 0) {
                listener.onComplete(articles);
            } else {
                this.errorMessage = this.errorMessage == null ? "The rss news feed is quite unstable, please try again by pull to refresh." : this.errorMessage;
                listener.onError(errorMessage);
            }

        }
    }

    private class DownloadArticleTask extends AsyncTask<Void, Void, String> {

        private String urlLink;
        private String errorMessage;

        DownloadArticleTask(String link) {
            this.urlLink = link;
        }

        @Override
        protected void onPreExecute() {
        }

        @Override
        protected String doInBackground(Void... voids) {
            if (TextUtils.isEmpty(urlLink))
                return null;
            if (!urlLink.startsWith("http://") && !urlLink.startsWith("https://"))
                urlLink = "http://" + urlLink;
            String htmlData = "";
            try {
                Document doc = Jsoup.connect(this.urlLink).get();
                doc.head().appendElement("link").attr("rel", "stylesheet").attr("type", "text/css").attr("href", "style.css");
                htmlData = doc.outerHtml();
            } catch (IOException e) {
                this.errorMessage = "The device might be out of disk space";
                e.printStackTrace();
            }
            return htmlData;
        }

        @Override
        protected void onPostExecute(String htmlData) {
            if (htmlData != null && !htmlData.isEmpty()) {
                listener.onDownloadArticleSuccess(htmlData);
            } else {
                this.errorMessage = this.errorMessage == null ? "There is a problem while download article, please try again" : this.errorMessage;
                listener.onError(errorMessage);
            }

        }
    }

    public interface Listener {
        void onComplete(List<Article> articles);

        void onDownloadArticleSuccess(String htmlData);

        void onError(String error);
    }
}
