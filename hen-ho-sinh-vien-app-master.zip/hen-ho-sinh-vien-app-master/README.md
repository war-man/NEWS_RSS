# Source Code Hẹn Hò Sinh Viên App
Đây là dự án môn học lập trình di động, app sử dụng firebase để có tính năng realtime.
App bao gồm các chức năng chính:
+ Chat trực tiếp
+ Tin nhắn đang chờ
+ Kết bạn
+ Tìm bạn ngẫu nhiên

