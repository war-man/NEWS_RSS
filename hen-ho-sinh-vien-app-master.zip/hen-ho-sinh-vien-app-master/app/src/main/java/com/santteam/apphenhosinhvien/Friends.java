package com.santteam.apphenhosinhvien;

/**
 * Created by nqait97 on 11-Nov-17.
 */

public class Friends {
    public String date;

    public Friends() {
    }

    public Friends(String date) {
        this.date = date;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }
}
