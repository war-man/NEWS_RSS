# NEWS
## Getting started
A RSS-reader news Android app
## Layout
