package com.example.sridharjajoo.newsapp.di;

public interface Injectable {
}
