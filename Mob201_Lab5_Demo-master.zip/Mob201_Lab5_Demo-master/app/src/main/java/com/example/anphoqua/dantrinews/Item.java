package com.example.anphoqua.dantrinews;

public class Item  {
    String title;
    String link;
}
