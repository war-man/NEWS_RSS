package com.tbn.duan2.NTB;

public class Weblink {
    public static String Image="https://nhom1.ga/api/json";
    public static String Home="https://nhom1.ga";
    public static String Category="https://nhom1.ga/api/json2";
}
