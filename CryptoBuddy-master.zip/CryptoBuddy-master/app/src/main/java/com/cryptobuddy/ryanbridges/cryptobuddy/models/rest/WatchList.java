package com.cryptobuddy.ryanbridges.cryptobuddy.models.rest;

/**
 * Created by fco on 10-01-18.
 */

public class WatchList {

    private String CoinIs;
    private String Sponsored;

    public String getCoinIs() {
        return CoinIs;
    }

    public void setCoinIs(String coinIs) {
        CoinIs = coinIs;
    }

    public String getSponsored() {
        return Sponsored;
    }

    public void setSponsored(String sponsored) {
        Sponsored = sponsored;
    }

}
