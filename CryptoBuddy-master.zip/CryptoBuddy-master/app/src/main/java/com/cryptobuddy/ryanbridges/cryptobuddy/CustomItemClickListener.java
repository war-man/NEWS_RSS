package com.cryptobuddy.ryanbridges.cryptobuddy;

import android.view.View;

/**
 * Created by Ryan on 8/13/2017.
 */

public interface CustomItemClickListener {
    void onItemClick(int position, View v);
}
