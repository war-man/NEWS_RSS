package com.cryptobuddy.ryanbridges.cryptobuddy;


public interface DrawerController {
    void hideHamburger();
    void showHamburger();
}
