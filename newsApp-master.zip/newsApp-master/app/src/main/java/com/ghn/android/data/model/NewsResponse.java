package com.ghn.android.data.model;

import java.io.Serializable;

/**
 * Created by AMIT on 3/31/2016.
 */
public class NewsResponse implements Serializable {


}
