package com.ghn.android.util;

import java.io.Serializable;

/**
 * Created by AMIT on 4/5/2016.
 */
public interface ToggleToolbarViewListener extends Serializable {

  void toggleVisibilityOfToolbar();
}
