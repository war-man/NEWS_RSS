package com.ghn.android;

/**
 * Created by AMIT on 4/9/2016.
 */
public class QuickstartPreferences {
  public static final String SENT_TOKEN_TO_SERVER = "sentTokenToServer";
  public static final String REGISTRATION_COMPLETE = "registrationComplete";
}
