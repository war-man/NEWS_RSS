package com.example.duongtainhan555.newsapp.Interface;

public interface PositionListView {
    void PosList(int pos);
    void RemovePos(int pos);

}
