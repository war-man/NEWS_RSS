package com.example.duongtainhan555.newsapp.Models.News;

public class TypeItem {
    private String typeNews;

    public void setTypeNews(String typeNews) {
        this.typeNews = typeNews;
    }

    public String getTypeNews() {
        return typeNews;
    }
}
