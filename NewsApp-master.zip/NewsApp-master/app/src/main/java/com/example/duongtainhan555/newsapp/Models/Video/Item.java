package com.example.duongtainhan555.newsapp.Models.Video;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class Item {

@SerializedName("id")
@Expose
private Id id;
@SerializedName("snippet")
@Expose
private Snippet snippet;

public Id getId() {
return id;
}

public void setId(Id id) {
this.id = id;
}

public Snippet getSnippet() {
return snippet;
}

public void setSnippet(Snippet snippet) {
this.snippet = snippet;
}

}